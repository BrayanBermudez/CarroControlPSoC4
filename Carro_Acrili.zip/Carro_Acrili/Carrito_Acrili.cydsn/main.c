/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
void adelante();
void atras();
void derecha();
void izquierda();
void quieto();

CY_ISR (interruptRx)
{
    char dato;
    
    dato=UART_GetChar();
    
    if (dato == 't')
    {
        adelante();
    }
    if (dato == 'v')
    {
        atras();
    }
    if (dato == 'a')
    {
        izquierda();
    }
    if (dato == 'l')
    {
        derecha();
    }
    if (dato == 'm')
    {
        quieto();
    }
    
}


int main()
{
    CyGlobalIntEnable; 
    UART_Start();
    
    isrRx_StartEx(interruptRx);
    
    for(;;)
    {
        
    }
}

void adelante()
{
    Motor1_1_Write(1);
    Motor1_2_Write(0);
    
    Motor2_1_Write(1);
    Motor2_2_Write(0);
    
    Motor3_1_Write(1);
    Motor3_2_Write(0);
    
    
    Motor4_1_Write(1);
    Motor4_2_Write(0);
    
}
void atras()
{
    Motor1_1_Write(0);
    Motor1_2_Write(1);
    
    Motor2_1_Write(0);
    Motor2_2_Write(1);
    
    Motor3_1_Write(0);
    Motor3_2_Write(1);
    
    
    Motor4_1_Write(0);
    Motor4_2_Write(1);
}

void izquierda()
{
    Motor1_1_Write(1);
    Motor1_2_Write(0);
    
    Motor2_1_Write(1);
    Motor2_2_Write(0);
    
    Motor3_1_Write(0);
    Motor3_2_Write(1);
    
    
    Motor4_1_Write(0);
    Motor4_2_Write(1);
}
void derecha()
{
    Motor1_1_Write(0);
    Motor1_2_Write(1);
    
    Motor2_1_Write(0);
    Motor2_2_Write(1);
    
    Motor3_1_Write(1);
    Motor3_2_Write(0);
    
    
    Motor4_1_Write(1);
    Motor4_2_Write(0);
}
void quieto()
{
    Motor1_1_Write(0);
    Motor1_2_Write(0);
    
    Motor2_1_Write(0);
    Motor2_2_Write(0);
    
    Motor3_1_Write(0);
    Motor3_2_Write(0);
    
    
    Motor4_1_Write(0);
    Motor4_2_Write(0);

}
